﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PACMAN
{
    public partial class mainform : Form
    {
        bool moveRight = true;
        bool moveDown = false;
        bool moveLeft = false;
        bool moveUp = false;

        public mainform()
        {
            InitializeComponent();
            pacmangif.Image = Image.FromFile("pacman64-right.gif");
        }

        private void pacmangif_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {            
            if(moveRight == true)
            {
                if (pacmangif.Left < 1100)
                {                 
                    // move PacMan RIGHT
                    pacmangif.Left += 50;
                }
                else if (pacmangif.Left == 1100)
                {
                    pacmangif.Image = Image.FromFile("pacman64-down.gif");
                    moveRight = false;
                    moveDown = true;
                }
            }   
            else if(moveDown == true)
            {
                if (pacmangif.Top < 500)
                {                    
                    // move PacMan DOWN
                    pacmangif.Top += 50;
                }
                else if (pacmangif.Top == 500)
                {
                    pacmangif.Image = Image.FromFile("pacman64-left.gif");
                    moveDown = false;
                    moveLeft = true;
                }
            }            
            else if(moveLeft == true)
            {
                if (pacmangif.Left > 100)
                {                    
                    // move PacMan LEFT
                    pacmangif.Left -= 50;
                }
                else if (pacmangif.Left == 100)
                {
                    pacmangif.Image = Image.FromFile("pacman64-up.gif");
                    moveDown = false;
                    moveUp = true;                
                }
            }
            if(moveUp == true)
            {
                if (pacmangif.Top > 50)
                {                    
                    // move PacMan UP
                    pacmangif.Top -= 50;
                }
                else if (pacmangif.Top == 50)
                {
                    pacmangif.Image = Image.FromFile("pacman64-right.gif");
                    moveUp = false;
                    moveRight = true;
                }
            }            
        }
    }
}
