﻿
namespace PACMAN
{
    partial class mainform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pacmangif = new System.Windows.Forms.PictureBox();
            this.programLabel1 = new System.Windows.Forms.Label();
            this.programLabel2 = new System.Windows.Forms.Label();
            this.getStartedbtn = new System.Windows.Forms.Button();
            this.teamMembersLabel = new System.Windows.Forms.Label();
            this.pacmanMoveTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pacmangif)).BeginInit();
            this.SuspendLayout();
            // 
            // pacmangif
            // 
            this.pacmangif.InitialImage = null;
            this.pacmangif.Location = new System.Drawing.Point(550, 50);
            this.pacmangif.Name = "pacmangif";
            this.pacmangif.Size = new System.Drawing.Size(68, 65);
            this.pacmangif.TabIndex = 0;
            this.pacmangif.TabStop = false;
            this.pacmangif.Click += new System.EventHandler(this.pacmangif_Click);
            // 
            // programLabel1
            // 
            this.programLabel1.AutoEllipsis = true;
            this.programLabel1.Font = new System.Drawing.Font("Source Code Pro Black", 20F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.programLabel1.ForeColor = System.Drawing.Color.Yellow;
            this.programLabel1.Location = new System.Drawing.Point(260, 201);
            this.programLabel1.Name = "programLabel1";
            this.programLabel1.Size = new System.Drawing.Size(726, 32);
            this.programLabel1.TabIndex = 0;
            this.programLabel1.Tag = "frontLabels";
            this.programLabel1.Text = "The Prioritized Audit of Captures by Manual";
            this.programLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // programLabel2
            // 
            this.programLabel2.AutoEllipsis = true;
            this.programLabel2.AutoSize = true;
            this.programLabel2.Font = new System.Drawing.Font("Source Code Pro Black", 20F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.programLabel2.ForeColor = System.Drawing.Color.Yellow;
            this.programLabel2.Location = new System.Drawing.Point(235, 233);
            this.programLabel2.Name = "programLabel2";
            this.programLabel2.Size = new System.Drawing.Size(767, 34);
            this.programLabel2.TabIndex = 0;
            this.programLabel2.Tag = "frontLabels";
            this.programLabel2.Text = "Analysis over a Network (P.A.C. M.A.N.) Project";
            // 
            // getStartedbtn
            // 
            this.getStartedbtn.Font = new System.Drawing.Font("Stencil", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getStartedbtn.Location = new System.Drawing.Point(522, 390);
            this.getStartedbtn.Name = "getStartedbtn";
            this.getStartedbtn.Size = new System.Drawing.Size(179, 50);
            this.getStartedbtn.TabIndex = 1;
            this.getStartedbtn.Text = "Get Started!";
            this.getStartedbtn.UseVisualStyleBackColor = true;
            // 
            // teamMembersLabel
            // 
            this.teamMembersLabel.AutoEllipsis = true;
            this.teamMembersLabel.AutoSize = true;
            this.teamMembersLabel.Font = new System.Drawing.Font("Source Serif Pro Semibold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teamMembersLabel.ForeColor = System.Drawing.Color.Yellow;
            this.teamMembersLabel.Location = new System.Drawing.Point(222, 293);
            this.teamMembersLabel.Name = "teamMembersLabel";
            this.teamMembersLabel.Size = new System.Drawing.Size(789, 25);
            this.teamMembersLabel.TabIndex = 2;
            this.teamMembersLabel.Tag = "frontLabels";
            this.teamMembersLabel.Text = "Team Members: Ashley Godinez, Caleb Carpenter, Isai Rocha, Lucio Rubio, and Taylo" +
    "r Antonich";
            // 
            // pacmanMoveTimer
            // 
            this.pacmanMoveTimer.Enabled = true;
            this.pacmanMoveTimer.Interval = 300;
            this.pacmanMoveTimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1278, 644);
            this.Controls.Add(this.teamMembersLabel);
            this.Controls.Add(this.getStartedbtn);
            this.Controls.Add(this.programLabel2);
            this.Controls.Add(this.programLabel1);
            this.Controls.Add(this.pacmangif);
            this.Name = "mainform";
            this.Text = "P.A.C. M.A.N.";
            ((System.ComponentModel.ISupportInitialize)(this.pacmangif)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pacmangif;
        private System.Windows.Forms.Label programLabel1;
        private System.Windows.Forms.Label programLabel2;
        private System.Windows.Forms.Button getStartedbtn;
        private System.Windows.Forms.Label teamMembersLabel;
        private System.Windows.Forms.Timer pacmanMoveTimer;
    }
}

